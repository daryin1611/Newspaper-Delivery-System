Newspaper-Delivery-System-Project-
Group project to create a newspaper delivery system
------------------------------------------------------------------------------------------------------------------------------------------------------------------
User Guide
------------------------------------------------------------------------------------------------------------------------------------------------------------------
When you load into the program, there is a welcoming screen that welcomes you to the system, and prompts you to select an option from the combo box.
There are 5 options that are publications, carriers, household info, billing, and summary printout. Once you select one of the options, the welcoming messages
disappear, but the combo box stays, and you can change between each tab. Depending on the tab selected, the following will happen:

Publications
---------------------------------------------
If you click the publications tab, as soon as you enter the datalist will load up with the complete list of households (displaying house data), along with displaying 3
buttons, add new subscription,remove a subscription, and has subscription. If you click add new subscription, a second data list will load up with a list of all the 
publications available, along with another button. If you select a publication and click the add button, it will be added to the list of subscirptions the household has. 
If you click the remove subscription button, and the condition of the house having subscriptions is met, a second list of all the subscirptions the house has, and a 
second remove button will load up. You will then need to select the publication to remove, click the button, and then it will be removed from the list of publications. 
If you click the has subscription button, the second list will load up again with a list of all the publications, along with a check for subscription button. 
Once a selection is made from the list, and you click the button, if the house has that subscription a label will pop up saying they have the subscription,
 and if it doesn't have it that will be outputted.

Carriers
-----------------------------------------------
If you click the carriers tab, as soon as you enter the datalist will load up with the complete list of carriers (displaying carrier data), along with displaying 4 buttons,
carrier routes, add carrier, remove carrier, and modifying existing info. If you click the carrier routes button, a second button will appear that when clicked
a second list will pop up displaying the routes the selected house has. If you click add carrier, 3 text boxes appear, and once data is entered, and the second button that
appears is clciked, it adds a new carrier to the list of carriers. If you click remove carrier, a second button appears that when clicked removes the selected carrier from
the list. If you click Modify Existing Info, 3 text boxes will pop up, along with a second button. If data is entered into any of these text boxes, and the button is clicked
it changes the selected carriers data. If a text box is left alone, then the data of that carrier will remian the same.

Household Info
-----------------------------------------------
If you click the household info tab, as soon as you enter the datalist will load up with the complete list of households, along with displaying 4 buttons, add household,
delete household, modify existing info, and suspend/unsuspend household.  If you click add  household, 3 text boxes appear, and once data is entered, and the second button 
that appears is clicked, it adds a new household to the list of households. If you click remove household, a second button appears that when clicked removes the selected 
household from the list of households. If you click Modify Existing Info, 3 text boxes will pop up, along with a second button. If data is entered into any of these text 
boxes, and the button is clicked it changes the selected household data. If a text box is left alone, then the data of that household will remian the same. If you click
Suspend/Unsuspend household, a second button will appear that when clicked will check the status of delivery for that house (whether it's suspended or not), and change it
to the opposite status. 

Billing
------------------------------------------------
If you click the billing tab, as soon as you enter the datalist will load up with the complete list of households, along with 2 buttons. The display house' sub list will
load a second list of all the publications the selected house is subscribed to. If the view total owed button is clicked, a message will appear outputting the number of
subscriptions the household has, along with the amount owed for all of them combined. There is also an option to input an amount of payment, and once a positive amount is
entered and the update bill button is clicked, it will update the amount of money owed, and if change needs to be returned.

Summary Printout
-----------------------------------------------
If you click the summary printout tab, as soon as you enter the datalist will load up with the complete list of publications, along with a view summary button. Once a
publication is selected, and the button is clicked, a message outputs the number of households subscribed to the publication, along with the amount of money that is owed
between all the subscribers.